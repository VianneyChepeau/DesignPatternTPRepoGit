#ifndef FIGURE_H
#define FIGURE_H

class Figure {


public:
	void dessiner();

	void calculerSufrace();
};

#endif
