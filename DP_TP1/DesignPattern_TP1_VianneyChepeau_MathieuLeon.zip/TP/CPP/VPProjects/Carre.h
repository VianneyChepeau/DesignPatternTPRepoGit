#ifndef CARRE_H
#define CARRE_H

class Carre : Rectangle {


public:
	void dessiner();

	void calculerSurface();
};

#endif
