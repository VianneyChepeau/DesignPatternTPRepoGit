#ifndef CAMERA_H
#define CAMERA_H

class Camera {
};

#endif
