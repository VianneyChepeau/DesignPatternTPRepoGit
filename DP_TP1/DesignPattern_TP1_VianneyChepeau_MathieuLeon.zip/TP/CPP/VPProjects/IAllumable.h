#ifndef IALLUMABLE_H
#define IALLUMABLE_H

class IAllumable {


public:
	void allumer();

	void eteindre();
};

#endif
