#include "IPositionnable.h"

void IPositionnable::getX() {
	// A faire - implementer IPositionnable::getX
	throw "A implementer";
}

void IPositionnable::setX() {
	// A faire - implementer IPositionnable::setX
	throw "A implementer";
}

void IPositionnable::getY() {
	// A faire - implementer IPositionnable::getY
	throw "A implementer";
}

void IPositionnable::setY() {
	// A faire - implementer IPositionnable::setY
	throw "A implementer";
}
