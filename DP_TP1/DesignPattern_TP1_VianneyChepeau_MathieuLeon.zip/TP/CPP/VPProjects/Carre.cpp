#include "Carre.h"

void Carre::dessiner() {
	// A faire - implementer Carre::dessiner
	throw "A implementer";
}

void Carre::calculerSurface() {
	// // A faire - implementer Carre::calculerSurface
	throw "A implementer";
}
