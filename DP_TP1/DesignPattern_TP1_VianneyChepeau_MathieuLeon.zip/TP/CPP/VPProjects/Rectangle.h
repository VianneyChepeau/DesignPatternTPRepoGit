#ifndef RECTANGLE_H
#define RECTANGLE_H

class Rectangle : Figure {

private:
	int longueur;
	int largeur;
	Point basGauche;

public:
	void dessiner();

	void calculerSurface();
};

#endif
