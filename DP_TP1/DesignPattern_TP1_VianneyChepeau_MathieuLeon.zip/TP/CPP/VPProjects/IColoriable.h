#ifndef ICOLORIABLE_H
#define ICOLORIABLE_H

class IColoriable {

private:
	int r;
	int g;
	int b;

public:
	void getR();

	void setR(int r);

	void getG();

	void setG(int g);

	void getB();

	void setB(int b);

	void colorier(int r, int g, int b);
};

#endif
