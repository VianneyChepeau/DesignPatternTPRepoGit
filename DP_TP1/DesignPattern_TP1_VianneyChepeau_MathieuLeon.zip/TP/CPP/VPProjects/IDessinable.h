#ifndef IDESSINABLE_H
#define IDESSINABLE_H

class IDessinable : IColoriable, IPositionnable {
};

#endif
