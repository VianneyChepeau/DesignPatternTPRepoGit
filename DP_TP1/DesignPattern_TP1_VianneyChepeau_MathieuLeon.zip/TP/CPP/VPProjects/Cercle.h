#ifndef CERCLE_H
#define CERCLE_H

class Cercle : Figure {

private:
	int rayon;
	Point centre;

public:
	void dessiner();

	void calculerSurface();

	void getRayon();

	void setRayon(int rayon);

	void getCentre();

	void setCentre(int centre);
};

#endif
