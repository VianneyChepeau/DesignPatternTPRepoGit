#include "IAllumable.h"

void IAllumable::allumer() {
	// A faire - implementer IAllumable::allumer
	throw "A implementer";
}

void IAllumable::eteindre() {
	// A faire - implementer IAllumable::eteindre
	throw "A implementer";
}
