#include "Rectangle.h"

void Rectangle::dessiner() {
	// A faire - implementer Rectangle::dessiner
	throw "A implementer";
}

void Rectangle::calculerSurface() {
	// A faire - implementer Rectangle::calculerSurface
	throw "A implementer";
}
