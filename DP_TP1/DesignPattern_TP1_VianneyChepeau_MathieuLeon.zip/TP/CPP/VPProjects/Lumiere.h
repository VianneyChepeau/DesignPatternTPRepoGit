#ifndef LUMIERE_H
#define LUMIERE_H

class Lumiere {
};

#endif
