#include "Figure.h"

void Figure::dessiner() {
	// A faire - implementer Figure::dessiner
	throw "A implementer";
}

void Figure::calculerSufrace() {
	// A faire - implementer Figure::calculerSufrace
	throw "A implementer";
}
