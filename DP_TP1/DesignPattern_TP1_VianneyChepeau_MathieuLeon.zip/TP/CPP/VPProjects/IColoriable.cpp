#include "IColoriable.h"

void IColoriable::getR() {
	// A faire - implementer IColoriable::getR
	throw "A implementerd";
}

void IColoriable::setR(int r) {
	this->r = r;
}

void IColoriable::getG() {
	// A faire - implementer IColoriable::getG
	throw "A implementer";
}

void IColoriable::setG(int g) {
	this->g = g;
}

void IColoriable::getB() {
	// A faire - implementer IColoriable::getB
	throw "A implementer";
}

void IColoriable::setB(int b) {
	this->b = b;
}

void IColoriable::colorier(int r, int g, int b) {
	// A faire - implementer IColoriable::colorier
	throw "A implementer";
}
