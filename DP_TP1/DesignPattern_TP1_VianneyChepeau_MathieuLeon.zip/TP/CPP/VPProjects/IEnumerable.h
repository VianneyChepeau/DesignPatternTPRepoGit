#ifndef IENUMERABLE_H
#define IENUMERABLE_H

class IEnumerable {
};

#endif
