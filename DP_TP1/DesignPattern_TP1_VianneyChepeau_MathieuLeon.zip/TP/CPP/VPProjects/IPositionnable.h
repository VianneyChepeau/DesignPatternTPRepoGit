#ifndef IPOSITIONNABLE_H
#define IPOSITIONNABLE_H

class IPositionnable {

private:
	float dx;
	float dy;

public:
	void getX();

	void setX();

	void getY();

	void setY();
};

#endif
