#include "Cercle.h"

void Cercle::dessiner() {
	// A faire - implementer Cercle::dessiner
	throw "A implementer";
}

void Cercle::calculerSurface() {
	// A faire - implementer Cercle::calculerSurface
	throw "A implementer";
}

void Cercle::getRayon() {
	// A faire - implementer Cercle::getRayon
	throw "A implementer";
}

void Cercle::setRayon(int rayon) {
	this->rayon = rayon;
}

void Cercle::getCentre() {
	// A faire - implementer Cercle::getCentre
	throw "A implementerd";
}

void Cercle::setCentre(int centre) {
	// A faire - implementer Cercle::setCentre
	throw "A implementer";
}
