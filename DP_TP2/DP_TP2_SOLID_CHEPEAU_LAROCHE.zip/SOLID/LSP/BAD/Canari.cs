﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LSP.BAD
{
    public class Canari : Oiseau
    {
        public override void Manger()
        {
            Console.WriteLine("Je suis un canari et je mange...");
        }
    }
}
