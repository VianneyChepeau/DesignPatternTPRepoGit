﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LSP
{
    public abstract class Oiseau
    {
        public abstract void Manger();
    }
}